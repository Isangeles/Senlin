1. INTRODUCTION
Senlin is 2D cRPG game with isometric view written from scratch in Java with Slick2D library.
Currently in very early development stage.

2. INSTALLATION
Simply download and unpack build.

3. RUN
Simply run senlin executable(.sh on Linux or .exe on Windows).

If you have problem with game startup, try to change game resolution(in settings.txt) to your current resolution or one of these: 1920x1080, 1600x800, 1280x720.
